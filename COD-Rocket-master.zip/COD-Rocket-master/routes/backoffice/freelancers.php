<?php

Route::group(['as' => 'freelancers.'], function() {
});