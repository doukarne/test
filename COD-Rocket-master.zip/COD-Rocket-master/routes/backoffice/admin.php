<?php

Route::group(['as' => 'admin.'], function() {
});