<?php

namespace App\Livewire\Merchant\Balance;

use App\Livewire\Component;

class BalanceHistory extends Component
{
    public function render()
    {
        return view('merchant.balance.balance-history');
    }
}
