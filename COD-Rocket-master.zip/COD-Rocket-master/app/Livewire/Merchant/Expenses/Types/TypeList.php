<?php

namespace App\Livewire\Merchant\Expenses\Types;

use App\Livewire\Component;

class TypeList extends Component
{
    public function render()
    {
        return view('merchant.expenses.types.type-list');
    }
}
