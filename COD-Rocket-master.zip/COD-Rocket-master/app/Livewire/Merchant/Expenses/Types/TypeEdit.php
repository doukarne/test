<?php

namespace App\Livewire\Merchant\Expenses\Types;

use App\Livewire\Component;

class TypeEdit extends Component
{
    public function render()
    {
        return view('merchant.expenses.types.type-edit');
    }
}
