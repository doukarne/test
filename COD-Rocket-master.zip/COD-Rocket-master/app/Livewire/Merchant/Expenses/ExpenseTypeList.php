<?php

namespace App\Livewire\Merchant\Expenses;

use App\Livewire\Component;

class ExpenseTypeList extends Component
{
    public function render()
    {
        return view('merchant.expenses.expense-type-list');
    }
}
