<?php

namespace App\Livewire\Merchant\Expenses;

use App\Livewire\Component;

class ExpenseEdit extends Component
{
    public function render()
    {
        return view('merchant.expenses.expense-edit');
    }
}
