<?php

namespace App\Livewire\Merchant\Customers;

use App\Livewire\Component;

class CustomerEdit extends Component
{
    public function render()
    {
        return view('merchant.customers.customer-edit');
    }
}
