<?php

namespace App\Livewire\Merchant\OrderForm;

use App\Livewire\Component;

class Forms extends Component
{
    public function render()
    {
        return view('merchant.order-form.forms');
    }
}
