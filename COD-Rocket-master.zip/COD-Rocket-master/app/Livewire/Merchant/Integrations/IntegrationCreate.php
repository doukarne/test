<?php

namespace App\Livewire\Merchant\Integrations;

use App\Livewire\Component;

class IntegrationCreate extends Component
{
    public function render()
    {
        return view('merchant.interations.integration-create');
    }
}
