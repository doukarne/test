<?php

namespace App\Livewire\Merchant\Integrations;

use App\Livewire\Component;

class IntegrationList extends Component
{
    public function render()
    {
        return view('merchant.integrations.integration-list');
    }
}
