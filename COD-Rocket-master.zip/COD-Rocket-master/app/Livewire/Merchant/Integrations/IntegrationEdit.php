<?php

namespace App\Livewire\Merchant\Integrations;

use App\Livewire\Component;

class IntegrationEdit extends Component
{
    public function render()
    {
        return view('merchant.interations.integration-edit');
    }
}
