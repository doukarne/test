<?php

namespace App\Livewire\Merchant\Orders;

use App\Livewire\Component;

class OrderImport extends Component
{
    public function render()
    {
        return view('merchant.orders.order-import');
    }
}
