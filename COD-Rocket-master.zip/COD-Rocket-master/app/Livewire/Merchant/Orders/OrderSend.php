<?php

namespace App\Livewire\Merchant\Orders;

use App\Livewire\Component;

class OrderSend extends Component
{
    public function render()
    {
        return view('merchant.orders.order-send');
    }
}
