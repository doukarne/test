<?php

namespace App\Livewire\Merchant\Services;

use App\Livewire\Component;

class ServiceView extends Component
{
    public function render()
    {
        return view('merchant.services.service-view');
    }
}
