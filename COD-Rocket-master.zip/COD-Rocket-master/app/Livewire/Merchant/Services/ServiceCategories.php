<?php

namespace App\Livewire\Merchant\Services;

use App\Livewire\Component;

class ServiceCategories extends Component
{
    public function render()
    {
        return view('merchant.services.service-categories');
    }
}
