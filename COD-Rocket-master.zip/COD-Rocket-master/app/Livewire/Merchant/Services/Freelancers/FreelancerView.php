<?php

namespace App\Livewire\Merchant\Services\Freelancers;

use App\Livewire\Component;

class FreelancerView extends Component
{
    public function render()
    {
        return view('merchant.services.freelancers.freelancer-view');
    }
}
