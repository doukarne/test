<?php

namespace App\Livewire\Merchant\Services\Freelancers;

use App\Livewire\Component;

class FreelancerList extends Component
{
    public function render()
    {
        return view('merchant.services.freelancers.freelancer-list');
    }
}
