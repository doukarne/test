<?php

namespace App\Livewire\Merchant\Services;

use App\Livewire\Component;

class ServiceList extends Component
{
    public function render()
    {
        return view('merchant.services.service-list');
    }
}
