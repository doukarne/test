<?php

namespace App\Livewire\Merchant;

use App\Livewire\Component;

class Support extends Component
{
    public function render()
    {
        return view('merchant.support');
    }
}
