<?php

namespace App\Livewire\Merchant\Partnerships\Freelancers;

use App\Livewire\Component;

class PartnershipList extends Component
{
    public function render()
    {
        return view('merchant.partnerships.deliverers.partnership-list');
    }
}
