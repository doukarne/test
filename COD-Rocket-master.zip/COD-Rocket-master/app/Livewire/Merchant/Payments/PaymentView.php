<?php

namespace App\Livewire\Merchant\Payments;

use App\Livewire\Component;

class PaymentView extends Component
{
    public function render()
    {
        return view('merchant.payments.payment-view');
    }
}
