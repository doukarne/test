<?php

namespace App\Livewire\Merchant\Products\Warehouses;

use App\Livewire\Component;

class WarehouseList extends Component
{
    public function render()
    {
        return view('merchant.products.warehouses.warehouse-list');
    }
}
