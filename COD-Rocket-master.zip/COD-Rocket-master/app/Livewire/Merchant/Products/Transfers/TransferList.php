<?php

namespace App\Livewire\Merchant\Products\Transfers;

use App\Livewire\Component;

class TransferList extends Component
{
    public function render()
    {
        return view('merchant.products.transfers.transfer-list');
    }
}
