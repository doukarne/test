<?php

namespace App\Livewire\Merchant\Products\Transfers;

use App\Livewire\Component;

class TransferCreate extends Component
{
    public function render()
    {
        return view('merchant.products.transfers.transfer-create');
    }
}
