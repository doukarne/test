<?php

namespace App\Livewire\Merchant\Products;

use App\Livewire\Component;

class ProductList extends Component
{
    public function render()
    {
        return view('merchant.products.product-list');
    }
}
