<?php

namespace App\Livewire\Forms\Orders;

use Livewire\Attributes\Validate;
use Livewire\Form;

class OrderForm extends Form
{
    //
}
