<?php

namespace App\Livewire;

use App\Livewire\Component;

class Profile extends Component
{
    public function render()
    {
        return view('profile');
    }
}
