<?php

namespace App\Livewire;

use App\Livewire\Component;

class Marketplace extends Component
{
    public function render()
    {
        return view('marketplace');
    }
}
