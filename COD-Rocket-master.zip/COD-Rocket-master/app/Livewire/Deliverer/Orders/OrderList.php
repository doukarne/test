<?php

namespace App\Livewire\Deliverer\Orders;

use App\Livewire\Component;

class OrderList extends Component
{
    public function render()
    {
        return view('deliverer.orders.order-list');
    }
}
