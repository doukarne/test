@section('title', __('Products'))

@section('breadcrumps')
	<x-ui.breadcrumps.item icon="archive-box">{{ __('Products') }}</x-ui.breadcrumps.item>
@endsection

<section></section>
