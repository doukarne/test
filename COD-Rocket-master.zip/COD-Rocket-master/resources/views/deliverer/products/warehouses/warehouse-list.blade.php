@section('title', __('Warehouses'))

@section('breadcrumps')
	<x-ui.breadcrumps.item icon="building-office">{{ __('Warehouses') }}</x-ui.breadcrumps.item>
@endsection

<section></section>