@section('title', __('Transfers'))

@section('breadcrumps')
	<x-ui.breadcrumps.item icon="arrows-right-left">{{ __('Transfers') }}</x-ui.breadcrumps.item>
@endsection

<section></section>