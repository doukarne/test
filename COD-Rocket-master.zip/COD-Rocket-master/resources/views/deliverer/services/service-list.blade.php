@section('title', __('Services'))

@section('breadcrumps')
	<x-ui.breadcrumps.item icon="building-storefront">{{ __('Services') }}</x-ui.breadcrumps.item>
@endsection

<section></section>