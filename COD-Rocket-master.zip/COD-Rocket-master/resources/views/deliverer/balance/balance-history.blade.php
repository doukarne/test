@section('title', __('Balance history'))

@section('breadcrumps')
	<x-ui.breadcrumps.item icon="list-bullet">{{ __('Balance history') }}</x-ui.breadcrumps.item>
@endsection

<section></section>