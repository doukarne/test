<div class="flex mt-auto items-center gap-2 bg-primary text-white py-1.5 px-2 rounded-lg">
    <x-ui.icon name="currency-dollar"/>
    <span class="text-sm flex w-full">{{ __('Balance') }} <small class="ml-auto text-sm font-bold">0$</small></span>
</div>