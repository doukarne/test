@section('title', __('Payment'))

@section('breadcrumps')
	<x-ui.breadcrumps.item icon="credit-card">{{ __('Payment') }}</x-ui.breadcrumps.item>
@endsection

<section></section>