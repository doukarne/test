@section('title', __('Freelancers'))

@section('breadcrumps')
	<x-ui.breadcrumps.item icon="credit-card">{{ __('Freelancers') }}</x-ui.breadcrumps.item>
@endsection

<section></section>