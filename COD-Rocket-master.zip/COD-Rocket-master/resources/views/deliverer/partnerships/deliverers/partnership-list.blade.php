@section('title', __('Deliverers'))

@section('breadcrumps')
	<x-ui.breadcrumps.item icon="truck">{{ __('Deliverers') }}</x-ui.breadcrumps.item>
@endsection

<section></section>