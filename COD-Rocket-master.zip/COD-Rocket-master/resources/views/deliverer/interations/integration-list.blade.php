@section('title', __('Sales channels'))

@section('breadcrumps')
	<x-ui.breadcrumps.item icon="cursor-arrow-ripple">{{ __('Sales channels') }}</x-ui.breadcrumps.item>
@endsection

<section></section>