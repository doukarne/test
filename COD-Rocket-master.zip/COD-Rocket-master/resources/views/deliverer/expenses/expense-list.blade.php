@section('title', __('Expenses'))

@section('breadcrumps')
	<x-ui.breadcrumps.item icon="banknotes">{{ __('Expenses') }}</x-ui.breadcrumps.item>
@endsection

<section></section>