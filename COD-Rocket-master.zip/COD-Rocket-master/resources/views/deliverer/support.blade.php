@section('title', __('Supoort'))

@section('breadcrumps')
	<x-ui.breadcrumps.item icon="ticket">{{ __('Supoort') }}</x-ui.breadcrumps.item>
@endsection

<section></section>