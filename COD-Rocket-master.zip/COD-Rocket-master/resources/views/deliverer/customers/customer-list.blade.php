@section('title', __('Customers'))

@section('breadcrumps')
	<x-ui.breadcrumps.item icon="users">{{ __('Customers') }}</x-ui.breadcrumps.item>
@endsection

<section></section>